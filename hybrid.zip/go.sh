#!/bin/bash

# Update & install dependensi
sudo apt update -y
sudo apt install -y nodejs npm python3 git

# Clone repo jika belum ada
if [ ! -d "Budjembud" ]; then
    git clone https://github.com/TAKIO716/Budjembud.git
fi

cd Budjembud

# Install npm dependencies
npm install

# Jalankan bot
node s.js