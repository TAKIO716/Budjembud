const mineflayer = require('mineflayer');
const Vec3 = require('vec3');

function createBot() {
  const bot = mineflayer.createBot({
    host: 'kalwi.id',
    port: 25565,
    username: 'Ryzz48',
    auth: 'offline',
    version: '1.18.1',
    skipValidation: true,
  });

  bot.on('login', () => {
    console.log('✅ Bot berhasil login ke server');
  });

  bot.once('spawn', async () => {
    console.log('🎮 Bot sudah spawn');

    try {
      await delay(10000);
      bot.chat('/login bangsat');
      console.log('🔐 Telah Login');

      await delay(4000);
      bot.chat('/move oneblock');
      console.log('🌍 /move oneblock');


      await delay(10000);
      bot.chat('/home a');
      console.log('🏠 Home');

     
      await delay(15000);
      bot.chat('/tptoggle disable');
      // Start semua otak
      startBlindMining(bot);
      await delay(7000);
      startAutoSell(bot);
      await delay(7000);         
      setupAutoPayOnCommand(bot);

    } catch (e) {
      console.log('❌ Error saat setup:', e.message);
      reconnect(bot);
    }
  });
bot.on('end', () => {
    console.log('🔌 Bot disconnect, reconnect dalam 5 detik...');
    setTimeout(createBot, 5000);
  });

  bot.on('error', (err) => {
    console.log('❌ Error:', err.message);
  });
}


function setupAutoPayOnCommand(bot) {
  bot.on('chat', async (sender, message) => {
    if (sender === 'AsKqaNaa' && message.trim().toLowerCase() === 'tes') {
      console.log(`💬 AsKqaNaa: "${message}"`);
      bot.chat('/balance');

      // Mulai dengar semua pesan selama 5 detik
      const listener = (msg) => {
        const text = msg.toString();
        console.log(`📨 Pesan masuk: "${text}"`);

        // Ubah regex jika format berbeda (lihat log hasil /balance)
        const match = text.match(/Your Balance:?\s*\$?([\d,]+)/i);
        if (match) {
          const amountStr = match[1].replace(/,/g, '');
          const amount = parseInt(amountStr);

          if (!isNaN(amount) && amount > 0) {
            bot.chat(`/pay AsKqaNaa ${amount}`);
            console.log(`💸 Mengirim uang: /pay AsKqaNaa ${amount}`);
          } else {
            console.warn(`⚠️ Saldo tidak valid: "${amountStr}"`);
          }

          bot.removeListener('message', listener);
          clearTimeout(timeout);
        }
      };

      bot.on('message', listener);

      const timeout = setTimeout(() => {
        bot.removeListener('message', listener);
        console.log('⌛ Timeout: Tidak ada pesan saldo dalam 5 detik.');
      }, 5000);
    }
  });
}



function isInAcidIsland(pos) {
  // Koordinat toleransi luas
  return pos.y > 50 && pos.y < 160 &&
         pos.x > -1000 && pos.x < 1000 &&
         pos.z > -1000 && pos.z < 1000;
}

async function ensureInAcidIsland(bot) {
  for (let i = 0; i < 5; i++) {
    const pos = bot.entity.position;
    console.log('📍 Posisi bot: X=${pos.x.toFixed(2)} Y=${pos.y.toFixed(2)} Z=${pos.z.toFixed(2)}');
    if (isInAcidIsland(pos)) return true;
    await delay(1000);
  }
  return false;
}

function reconnect(bot) {
  try {
    bot.quit();
  } catch {}
  setTimeout(createBot, 5000);
}

function startBlindMining(bot) {
  console.log('⛏ Otak 1: Mining 4 arah tanpa lihat');

  const directions = [
    new Vec3(0, 0, 1),   // belakang
    new Vec3(-1, 0, 0),  // kiri
    new Vec3(0, 0, -1),  // depan
    new Vec3(1, 0, 0),   // kanan
  ];

  let directionIndex = 0;

  async function digSide(dir) {
    for (let i = 1; i <= 7; i++) {
      const offset = dir.scaled(i);
      const targetPos = bot.entity.position.offset(offset.x, 1, offset.z);
      const targetBlock = bot.blockAt(targetPos);

      if (targetBlock && bot.canDigBlock(targetBlock)) {
        try {
          await bot.dig(targetBlock, 'ignore'); // tidak ubah pandangan
        } catch {}
      }

      await delay(60);
    }
  }

  async function digCycle() {
    while (true) {
      const dir = directions[directionIndex];
      await digSide(dir);
      directionIndex = (directionIndex + 1) % directions.length;
      await delay(10);
    }
  }

  digCycle();
}

function startAutoSell(bot) {
  console.log('💰 Otak 2: Auto /sell all tiap 5 detik');
  setInterval(() => {
    bot.chat('/sell all');
  }, 5000);
}

let awaitingBalance = false;

function startBalancePayLoop(bot) {
  console.log('📤 Otak 3: Cek /bal dan kirim /pay tiap 30 detik');
  setInterval(() => {
    bot.chat('/bal');
    awaitingBalance = true;
  }, 30000);
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

createBot();