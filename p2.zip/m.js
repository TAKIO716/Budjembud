const mineflayer = require('mineflayer');
const Vec3 = require('vec3');


function createBot() {
  const bot = mineflayer.createBot({
    host: 'kalwi.id',
    port: 25565, //port sesuai server
    username: 'Ryzz48',
    auth: 'offline', //bot mu akun crack apa premi
    version: '1.18.1', //pake versi suka" lu, gw si 1.18.1
    skipValidation: true,
  });

  bot.on('login', () => {
    console.log('✅ ALT dI Lobby');
  });

  bot.once('spawn', async () => {
    console.log('🎮 ALT Telah Spawn');

    try {
      await delay(3000);
      bot.chat('/login bangsat');
      console.log('🔐 sedang /login');

      await delay(5000);
      bot.chat('/move oneblock'); //pakailah subservernya
      console.log('🌍 /move oneblock');


      await delay(10000);
      bot.chat('/home a'); //untuk home usahakan sethome dlu dari awal | jika takmau make sethome boleh ganti pake /sell all
      console.log('🏠 /home a');


      await delay(15000);
      bot.chat('/tptoggle disable'); //untuk tptoggle supaya gaada yg tp

  
function autoEquipPickaxe(bot) {
  setInterval(async () => {
    try {
      // Kalau bot tidak memegang netherite_pickaxe
      if (!bot.heldItem || bot.heldItem.name !== 'netherite_pickaxe') {
        const pickaxe = bot.inventory.items().find(item => item.name === 'netherite_pickaxe');
        if (pickaxe) {
          await bot.equip(pickaxe, 'hand');
          console.log('🔧 Auto-equip netherite_pickaxe');
        }
      }
    } catch (err) {
      console.log('⚠️ Gagal equip pickaxe:', err.message);
    }
  }, 5000); // cek tiap 1 detik
}
 autoEquipPickaxe(bot);

      startBlindMining(bot);
      await delay(7000);
      startAutoSell(bot);

    } catch (e) {
      console.log('❌ Error saat setup:', e.message);
      reconnect(bot);
    }
  });
bot.on('end', () => {
    console.log('🔌 Bot disconnect, reconnect dalam 5 detik...');
    setTimeout(createBot, 5000);
  });

  bot.on('error', (err) => {
    console.log('❌ Error:', err.message);
  });
}

function isInAcidIsland(pos) {
  // BUAT mining 4 sisi
  return pos.y > 50 && pos.y < 160 &&
         pos.x > -1000 && pos.x < 1000 &&
         pos.z > -1000 && pos.z < 1000;
}

async function ensureInAcidIsland(bot) {
  for (let i = 0; i < 5; i++) {
    const pos = bot.entity.position;
    console.log('📍 Posisi bot: X=${pos.x.toFixed(2)} Y=${pos.y.toFixed(2)} Z=${pos.z.toFixed(2)}');
    if (isInAcidIsland(pos)) return true;
    await delay(1000);
  }
  return false;
}

function reconnect(bot) {
  try {
    bot.quit();
  } catch {}
  setTimeout(createBot, 5000);
}

function startBlindMining(bot) {
  console.log('⛏: Mining 4 arah tanpa lihat');

  const directions = [
    new Vec3(0, 0, 1),   // belakang
    new Vec3(-1, 0, 0),  // kiri
    new Vec3(0, 0, -1),  // depan
    new Vec3(1, 0, 0),   // kanan
  ];

  let directionIndex = 0;

  async function digSide(dir) {
  for (let i = 1; i <= 6; i++) {
    const offset = dir.scaled(i);

    for (let y = -3; y <= 3; y++) {
      const targetPos = bot.entity.position.offset(offset.x, y + 1, offset.z);
      const targetBlock = bot.blockAt(targetPos);

      if (targetBlock && bot.canDigBlock(targetBlock)) {
        try {
          await bot.dig(targetBlock, 'ignore');
        } catch {}
      }
    }

    await delay(60); // Delay tiap blok ke depan
  }
}

  async function digCycle() {
    while (true) {
      const dir = directions[directionIndex];
      await digSide(dir);
      directionIndex = (directionIndex + 1) % directions.length;
      await delay(10); //delay setiap 1 sisi USAHAKAN PAKE PICK MIRA
    }
  }

  digCycle();
}

function startAutoSell(bot) {
  console.log('💰: Auto /sell all tiap 2 detik');
  setInterval(() => {
    bot.chat('/sell');
  }, 5000); //paling aman si 2 detik JIKA TPS DROP tapi kalau server mengalami down memory penuh/cpu usage minimal [5 detik saja]
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

createBot();
