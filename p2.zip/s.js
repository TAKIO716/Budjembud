const { spawn, exec } = require("child_process");
const TelegramBot = require("node-telegram-bot-api");

const BOT_TOKEN = "7399450395:AAGi4m_0LVYorGdGZe063WwvjQsAq_jZerU";
const CHAT_ID = "6105537437";

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const delay = (ms) => new Promise((r) => setTimeout(r, ms));

const botFiles = ["m.js", "j.js", "j2.js", "j3.js", "j4.js"];
let runningBots = [];

// ===== START BOT FUNCTION =====
const startBot = (filename) => {
  console.log(`Menjalankan ${filename}...`);
  const child = spawn("node", [filename], { stdio: "inherit" });
  runningBots.push(child);

  child.on("close", (code) => {
    console.log(`${filename} selesai (code ${code})`);
  });
};

// ===== STOP ALL BOTS =====
const stopAllBots = async () => {
  console.log("🛑 Mematikan semua bot...");
  for (const child of runningBots) {
    child.kill("SIGTERM");
    await delay(5000); // jeda 5 detik antar stop
  }
  runningBots = [];
  console.log("✅ Semua bot dimatikan.");
};

// ===== RUN ALL BOTS =====
const runBots = async () => {
  console.log("🚀 Menyalakan semua bot...");
  for (const file of botFiles) {
    startBot(file);
    await delay(3000); // jeda antar start
  }
  console.log("✅ Semua bot dijalankan.");
};

// ===== RESTART ALL BOTS =====
const restartBots = async () => {
  console.log("🔁 Restarting semua bot...");
  await stopAllBots();
  await delay(5000);
  await runBots();
  console.log("✅ Restart selesai.");
};

// ===== TELEGRAM COMMAND =====
bot.onText(/\/on/, async (msg) => {
  if (msg.chat.id.toString() !== CHAT_ID) return;
  await runBots();
  bot.sendMessage(CHAT_ID, "✅ Semua bot telah dinyalakan.");
});

bot.onText(/\/off/, async (msg) => {
  if (msg.chat.id.toString() !== CHAT_ID) return;
  await stopAllBots();
  bot.sendMessage(CHAT_ID, "🛑 Semua bot telah dimatikan.");
});

bot.onText(/\/restart/, async (msg) => {
  if (msg.chat.id.toString() !== CHAT_ID) return;
  await restartBots();
  bot.sendMessage(CHAT_ID, "🔁 Semua bot telah direstart.");
});

bot.onText(/\/status/, (msg) => {
  if (msg.chat.id.toString() !== CHAT_ID) return;
  const status = runningBots.length
    ? `🟢 ${runningBots.length} bot sedang berjalan`
    : "🔴 Tidak ada bot yang berjalan.";
  bot.sendMessage(CHAT_ID, status);
});

console.log("📡 Controller Telegram aktif. Kirim /on, /off, atau /restart di chat botmu.");