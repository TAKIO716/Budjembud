// bot.js
const mineflayer = require('mineflayer');

const HOST = 'kalwi.id';
const PORT = 25565; // ubah kalau beda
const USERNAME = 'dark1441';
const VERSION = '1.18.1';
const PASSWORD = 'bangsat';

// Timing (ms)
const AFTER_LOGIN_MOVE_DELAY = 3000;      // setelah login kirim /move oneblock
const AFTER_MOVE_HOME_DELAY = 3000;       // setelah /move oneblock, kirim /home a
const AFTER_HOME_START_SELL_DELAY = 3000; // tunggu sebelum mulai loop /sell all
const SELL_INTERVAL_MS = 3000;            // /sell all tiap 3 detik
const HOME_INTERVAL_MS = 7000;           // /home a tiap 15 detik
const RECONNECT_DELAY_MS = 5000;

let sellInterval = null;
let homeInterval = null;
let currentBot = null;
let reconnectTimeout = null;

function createBot() {
  console.log('[bot] creating bot...');

  const bot = mineflayer.createBot({
    host: HOST,
    port: PORT,
    username: USERNAME,
    version: VERSION,
    auth: 'offline',
    skipValidation: true,
  });

  currentBot = bot;

  function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function stopIntervals() {
    if (sellInterval) {
      clearInterval(sellInterval);
      sellInterval = null;
    }
    if (homeInterval) {
      clearInterval(homeInterval);
      homeInterval = null;
    }
  }

  async function performFullSequence() {
    try {
      console.log('[bot] performing auto login');
      bot.chat(`/login ${PASSWORD}`);

      await wait(AFTER_LOGIN_MOVE_DELAY);
      console.log('[bot] moving to subserver oneblock...');
      bot.chat('/move oneblock');

      await wait(AFTER_MOVE_HOME_DELAY);
      console.log('[bot] teleporting to /home a');
      bot.chat('/home a');

      await wait(AFTER_HOME_START_SELL_DELAY);
      startSellLoop();
      startHomeLoop();
    } catch (err) {
      console.log('[bot] error in performFullSequence:', err);
    }
  }

  function startSellLoop() {
    if (sellInterval) clearInterval(sellInterval);
    console.log(`[bot] starting /sell all loop every ${SELL_INTERVAL_MS} ms`);
    bot.chat('/sell all');
    sellInterval = setInterval(() => {
      if (bot && bot.player) bot.chat('/sell all');
    }, SELL_INTERVAL_MS);
  }

  function startHomeLoop() {
    if (homeInterval) clearInterval(homeInterval);
    console.log(`[bot] starting /home a loop every ${HOME_INTERVAL_MS} ms`);
    bot.chat('/home a');
    homeInterval = setInterval(() => {
      if (bot && bot.player) bot.chat('/home a');
    }, HOME_INTERVAL_MS);
  }

  bot.on('spawn', async () => {
    console.log('[bot] spawned in world');
    stopIntervals();
    setTimeout(() => performFullSequence(), 1500);
  });

  bot.on('death', () => {
    console.log('[bot] died, will restart after respawn');
    stopIntervals();
  });

  bot.on('end', () => {
    console.log('[bot] disconnected, scheduling reconnect...');
    stopIntervals();
    scheduleReconnect();
  });

  bot.on('error', err => {
    console.log('[bot] error:', err.message);
    stopIntervals();
    scheduleReconnect();
  });

  bot.on('kicked', (reason) => {
    console.log('[bot] kicked:', reason);
  });

  function scheduleReconnect() {
    if (reconnectTimeout) return;
    reconnectTimeout = setTimeout(() => {
      reconnectTimeout = null;
      try { if (currentBot && currentBot.quit) currentBot.quit(); } catch (_) {}
      createBot();
    }, RECONNECT_DELAY_MS);
  }

  return bot;
}

createBot();

process.on('SIGINT', () => {
  console.log('\n[bot] shutting down...');
  try {
    if (currentBot && currentBot.quit) currentBot.quit();
  } catch (_) {}
  process.exit();
});